Datafiller example Dataset for "Schokofabrik"
=============================================

Generate testdata
-----------------
Read the tutorial or the quick reference for the proper usage of the --df comments in the create script!
`Word lists`_ should help you to get more meaningfull data.

*datafiller --size=10000 --null=0.00001 --offset=603 schokofabrik.sql > inserts.sql*

Change to template directory and fill database with the start.sql command-file!

Links
-----
- https://www.cri.ensmp.fr/people/coelho/datafiller.html
- https://www.cri.ensmp.fr/people/coelho/datafiller.py
- http://blog.coelho.net/database/2014/03/23/datafiller-2-0-0/
- http://blog.coelho.net/database/2013/12/01/datafiller-tutorial/

.. _`Word lists`: http://www.outpost9.com/files/WordLists.html
