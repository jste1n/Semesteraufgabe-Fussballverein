-- Lager
INSERT INTO Lager VALUES ('Abstellraum', 30);
INSERT INTO Lager VALUES ('Zwischenlager Klein', 150);
INSERT INTO Lager VALUES ('Zwischenlager Gross', 1600);
INSERT INTO Lager VALUES ('Reservelager', 600);
INSERT INTO Lager VALUES ('Zwischenlager Mittel', 600);
INSERT INTO Lager VALUES ('Speziallager', 500);
INSERT INTO Lager VALUES ('Area 51', 510);

