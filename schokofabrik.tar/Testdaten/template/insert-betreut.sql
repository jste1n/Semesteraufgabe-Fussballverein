-- betreut
INSERT INTO Betreut VALUES (37, 'Abstellraum');
INSERT INTO Betreut VALUES (25, 'Zwischenlager Klein');
INSERT INTO Betreut VALUES (15, 'Zwischenlager Gross');
INSERT INTO Betreut VALUES (21, 'Zwischenlager Gross');
INSERT INTO Betreut VALUES (30, 'Zwischenlager Gross');
INSERT INTO Betreut VALUES (10, 'Reservelager');
INSERT INTO Betreut VALUES (07, 'Zwischenlager Mittel');
INSERT INTO Betreut VALUES (22, 'Zwischenlager Mittel');
INSERT INTO Betreut VALUES (02, 'Area 51');
INSERT INTO Betreut VALUES (06, 'Area 51');
INSERT INTO Betreut VALUES (16, 'Area 51');


-- 3, 4, 9, 19, 23, 29, 31, 32, 35 arbeiten noch an nichts

