-- lagert
INSERT INTO lagert VALUES ('Zwischenlager Gross', 001, 10000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 002, 5000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 003, 10000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 004, 5000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 005, 8000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 006, 6500);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 007, 3000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 008, 4000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 009, 7000);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 010, 1500);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 011, 800);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 012, 780);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 013, 330);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 014, 880);
INSERT INTO lagert VALUES ('Zwischenlager Gross', 015, 1500);

INSERT INTO lagert VALUES ('Zwischenlager Mittel', 023, 1700);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 024, 1500);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 025, 1200);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 026, 2000);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 027, 300);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 001, 6000);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 003, 6000);
INSERT INTO lagert VALUES ('Zwischenlager Mittel', 005, 3500);

INSERT INTO lagert VALUES ('Zwischenlager Klein', 028, 7000);
INSERT INTO lagert VALUES ('Zwischenlager Klein', 029, 6000);
INSERT INTO lagert VALUES ('Zwischenlager Klein', 030, 5500);
INSERT INTO lagert VALUES ('Zwischenlager Klein', 016, 4400);
INSERT INTO lagert VALUES ('Zwischenlager Klein', 017, 3900);
INSERT INTO lagert VALUES ('Zwischenlager Klein', 018, 2200);

INSERT INTO lagert VALUES ('Reservelager', 019, 180);
INSERT INTO lagert VALUES ('Reservelager', 020, 245);
INSERT INTO lagert VALUES ('Reservelager', 021, 10);
INSERT INTO lagert VALUES ('Reservelager', 022, 340);
INSERT INTO lagert VALUES ('Reservelager', 028, 400);
INSERT INTO lagert VALUES ('Reservelager', 016, 500);

INSERT INTO lagert VALUES ('Speziallager', 002, 2500);
INSERT INTO lagert VALUES ('Speziallager', 004, 2500);
INSERT INTO lagert VALUES ('Speziallager', 006, 2500);
INSERT INTO lagert VALUES ('Speziallager', 008, 2500);
INSERT INTO lagert VALUES ('Speziallager', 010, 1);
INSERT INTO lagert VALUES ('Speziallager', 101, 1);
INSERT INTO lagert VALUES ('Speziallager', 102, 1);
INSERT INTO lagert VALUES ('Speziallager', 103, 1);
INSERT INTO lagert VALUES ('Speziallager', 107, 1);
INSERT INTO lagert VALUES ('Speziallager', 009, 2);
INSERT INTO lagert VALUES ('Speziallager', 012, 5);
INSERT INTO lagert VALUES ('Speziallager', 013, 1);
INSERT INTO lagert VALUES ('Speziallager', 014, 1);

INSERT INTO lagert VALUES ('Abstellraum', 104, 1);
INSERT INTO lagert VALUES ('Abstellraum', 106, 1);
INSERT INTO lagert VALUES ('Abstellraum', 110, 1);
INSERT INTO lagert VALUES ('Abstellraum', 111, 1);
INSERT INTO lagert VALUES ('Abstellraum', 022, 34);


