-- Kunde
INSERT INTO Kunde VALUES ('Sweet and Sons', 'An der Donau 13, 1919 Unterberg', '00437654321');
INSERT INTO Kunde VALUES ('Schokoladenparadies Erdl', 'Marktweg 17A/5, 1087 Sobendorf', '004309090987');
INSERT INTO Kunde VALUES ('Gesuender Leben', 'Wadenstrasse 144, 3878 Kellersdorf', '00435148326');
INSERT INTO Kunde VALUES ('Chocolatier Holler', 'Bahnstrasse 10, 7658 Kolm', '00432020361');
INSERT INTO Kunde VALUES ('Ederle', 'Hanseweg 15, 9292 Neustadt', '00436868655');
INSERT INTO Kunde VALUES ('Megamarkt', 'An der Donau 14, 1919 Unterberg', '00437650215');
INSERT INTO Kunde VALUES ('Naschen, Ja!', 'Wohlstrasse 198, 2210 Erlstadt', '00433968758');
INSERT INTO Kunde VALUES ('Bitter und Scharf', 'Obere Landstrasse 184, 330 Umland', '00433624111');
