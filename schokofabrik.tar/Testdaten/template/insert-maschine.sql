INSERT INTO Maschine VALUES (0101, 'Mischer');
INSERT INTO Maschine VALUES (0102, 'Mischer');
INSERT INTO Maschine VALUES (0103, 'Mischer');
INSERT INTO Maschine VALUES (0104, 'Mischer');
INSERT INTO Maschine VALUES (0105, 'Mischer');

INSERT INTO Maschine VALUES (0201, 'Heizwerk klein');
INSERT INTO Maschine VALUES (0202, 'Heizwerk mittel');
INSERT INTO Maschine VALUES (0203, 'Heizwerk mittel');
INSERT INTO Maschine VALUES (0204, 'Heizwerk mittel');
INSERT INTO Maschine VALUES (0205, 'Heizwerk gross');

INSERT INTO Maschine VALUES (0301, 'Tank 30L');
INSERT INTO Maschine VALUES (0302, 'Tank 50L');
INSERT INTO Maschine VALUES (0303, 'Tank 100L');
INSERT INTO Maschine VALUES (0304, 'Tank 100L');
INSERT INTO Maschine VALUES (0305, 'Tank 100L');
INSERT INTO Maschine VALUES (0306, 'Tank 250L');
INSERT INTO Maschine VALUES (0307, 'Tank 250L');
INSERT INTO Maschine VALUES (0308, 'Tank 500L');

INSERT INTO Maschine VALUES (0401, 'Fuellanlage 1');
INSERT INTO Maschine VALUES (0402, 'Fuellanlage 2');

INSERT INTO Maschine VALUES (0501, 'Verpacker Typ I');
INSERT INTO Maschine VALUES (0502, 'Verpacker Typ I');
INSERT INTO Maschine VALUES (0503, 'Verpacker Typ II');
INSERT INTO Maschine VALUES (0504, 'Verpacker Typ II');
INSERT INTO Maschine VALUES (0505, 'Verpacker Typ III');

INSERT INTO Maschine VALUES (0601, 'Sekundaerverpacker');
INSERT INTO Maschine VALUES (0602, 'Sekundaerverpacker');
