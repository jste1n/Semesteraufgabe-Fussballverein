-- Produkt
INSERT INTO Produkt VALUES (001, 'Tafel Milchschokolade klein', 150);
INSERT INTO Produkt VALUES (002, 'Tafel Milchschokolade gross', 300);
INSERT INTO Produkt VALUES (003, 'Tafel Weisse Schokolade klein', 150);
INSERT INTO Produkt VALUES (004, 'Tafel Weisse Schokolade gross', 300);
INSERT INTO Produkt VALUES (005, 'Tafel Dunkle Schokolade klein', 150);
INSERT INTO Produkt VALUES (006, 'Tafel Dunkle Schokolade gross', 300);
INSERT INTO Produkt VALUES (007, 'Tafel Milchschokolade mit Nuessen klein', 150);
INSERT INTO Produkt VALUES (008, 'Tafel Milchschokolade mit Nuessen gross', 300);
INSERT INTO Produkt VALUES (009, 'Tafel Weisse Schokolade mit Nuessen klein', 150);
INSERT INTO Produkt VALUES (010, 'Tafel Weisse Schokolade mit Nuessen gross', 300);

INSERT INTO Produkt VALUES (011, 'Pralinen mit Kirschfuellung', 250);
INSERT INTO Produkt VALUES (012, 'Pralinen mit Nussfuellung', 250);
INSERT INTO Produkt VALUES (013, 'Pralinen mit Nougatfuellung', 250);
INSERT INTO Produkt VALUES (014, 'Pralinen mit Marzipanfuellung', 250);
INSERT INTO Produkt VALUES (015, 'Pralinen gemischt', 250);

INSERT INTO Produkt VALUES (016, 'Kids Bar', 60);
INSERT INTO Produkt VALUES (017, 'Energy Bar', 80);
INSERT INTO Produkt VALUES (018, 'Fruchtriegel', 80);

INSERT INTO Produkt VALUES (019, 'Osterhase klein', 80);
INSERT INTO Produkt VALUES (020, 'Osterhase mittel', 140);
INSERT INTO Produkt VALUES (021, 'Osterhase gross', 230);
INSERT INTO Produkt VALUES (022, 'Osterlamm', 120);

INSERT INTO Produkt VALUES (023, 'Schokonikolo klein', 80);
INSERT INTO Produkt VALUES (024, 'Schokonikolo mittel', 140);
INSERT INTO Produkt VALUES (025, 'Schokonikolo gross', 230);
INSERT INTO Produkt VALUES (026, 'Weihnachtlicher Baumbehang', 350);
INSERT INTO Produkt VALUES (027, 'Schokoschirme', 210);

INSERT INTO Produkt VALUES (028, 'Mika Fender', 70);
INSERT INTO Produkt VALUES (029, 'Pluto', 90);
INSERT INTO Produkt VALUES (030, 'NandNs', 150);
INSERT INTO Produkt VALUES (031, 'Pluto', 180);



INSERT INTO Produkt VALUES (101, 'Der vitruvianische Mensch', 1370);
INSERT INTO Produkt VALUES (102, 'Das letzte Abendmahl', 2256);
INSERT INTO Produkt VALUES (103, 'Michelangelo''s David', 2547);

INSERT INTO Produkt VALUES (104, 'Weihnachtskrippe', 4605);
INSERT INTO Produkt VALUES (105, 'Weihnachtslandschaft', 3590);
INSERT INTO Produkt VALUES (106, 'Gluecksschwein Rosa', 1400);

INSERT INTO Produkt VALUES (107, 'Schokoladenskulptur "Der Schwan"', 2300);
INSERT INTO Produkt VALUES (108, 'Schokoladenskulptur "Das Piano"', 5120);
INSERT INTO Produkt VALUES (109, 'Schokoladenskulptur "Angst"', 1760);

INSERT INTO Produkt VALUES (110, 'Der Schrei', 2279);
INSERT INTO Produkt VALUES (111, '"Die Zauberfloete" - Ein Genuss mit besonderer Note', 3150);

INSERT INTO Produkt VALUES (112, 'Vereintes Europa', 1390);
INSERT INTO Produkt VALUES (113, 'Mona Lisa', 3070);
INSERT INTO Produkt VALUES (114, 'Die Anatomie des Menschen', 5380);

INSERT INTO Produkt VALUES (115, 'Wien bei Nacht', 4380);
INSERT INTO Produkt VALUES (116, 'Suesze Apokalypse', 1760);




