-- enthaelt
INSERT INTO enthaelt VALUES ('Sweet and Sons', 1, 001, 1000);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 1, 003, 500);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 1, 005, 500);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 1, 023, 200);

INSERT INTO enthaelt VALUES ('Sweet and Sons', 2, 001, 800);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 2, 003, 800);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 2, 005, 300);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 2, 007, 300);

INSERT INTO enthaelt VALUES ('Sweet and Sons', 3, 001, 200);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 3, 002, 1000);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 3, 003, 200);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 3, 004, 1000);

INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 001, 400);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 002, 400);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 003, 400);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 004, 400);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 005, 100);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 006, 100);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 007, 100);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 4, 008, 100);

INSERT INTO enthaelt VALUES ('Sweet and Sons', 5, 023, 1000);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 5, 024, 500);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 5, 026, 500);
INSERT INTO enthaelt VALUES ('Sweet and Sons', 5, 027, 300);


INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 019, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 020, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 021, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 022, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 023, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 001, 500);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 002, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 003, 500);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 004, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 005, 500);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 1, 006, 300);

INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 007, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 008, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 009, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 010, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 001, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 003, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 2, 005, 150);


INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 023, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 024, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 025, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 026, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 027, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 104, 1);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 3, 105, 1);

INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 011, 300);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 012, 120);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 013, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 014, 100);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 015, 120);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 4, 016, 170);

INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 001, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 002, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 003, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 004, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 005, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 006, 150);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 5, 007, 400);

INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 016, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 017, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 018, 400);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 028, 200);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 029, 200);
INSERT INTO enthaelt VALUES ('Schokoladenparadies Erdl', 6, 030, 350);


INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 023, 700);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 024, 500);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 025, 200);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 026, 600);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 027, 280);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 017, 10000);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 1, 029, 300);

INSERT INTO enthaelt VALUES ('Gesuender Leben', 2, 011, 700);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 2, 012, 500);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 2, 013, 200);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 2, 014, 600);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 2, 015, 280);

INSERT INTO enthaelt VALUES ('Gesuender Leben', 3, 017, 12000);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 3, 114, 1);

INSERT INTO enthaelt VALUES ('Gesuender Leben', 4, 002, 400);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 4, 004, 500);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 4, 006, 200);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 4, 008, 600);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 4, 010, 290);

INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 001, 800);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 003, 800);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 005, 800);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 007, 800);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 009, 800);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 028, 1300);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 5, 030, 1300);

INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 002, 500);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 004, 300);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 006, 120);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 008, 300);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 010, 300);
INSERT INTO enthaelt VALUES ('Gesuender Leben', 6, 029, 700);


INSERT INTO enthaelt VALUES ('Chocolatier Holler', 1, 101, 1);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 1, 102, 1);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 1, 103, 1);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 1, 015, 40);

INSERT INTO enthaelt VALUES ('Chocolatier Holler', 2, 107, 1);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 2, 108, 1);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 2, 005, 100);

INSERT INTO enthaelt VALUES ('Chocolatier Holler', 3, 006, 20);
INSERT INTO enthaelt VALUES ('Chocolatier Holler', 3, 003, 60);


INSERT INTO enthaelt VALUES ('Ederle', 1, 001, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 002, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 003, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 004, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 005, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 006, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 007, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 008, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 009, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 010, 400);
INSERT INTO enthaelt VALUES ('Ederle', 1, 016, 700);
INSERT INTO enthaelt VALUES ('Ederle', 1, 017, 700);
INSERT INTO enthaelt VALUES ('Ederle', 1, 018, 700);

INSERT INTO enthaelt VALUES ('Ederle', 2, 023, 300);
INSERT INTO enthaelt VALUES ('Ederle', 2, 026, 100);
INSERT INTO enthaelt VALUES ('Ederle', 2, 027, 600);
INSERT INTO enthaelt VALUES ('Ederle', 2, 030, 700);

INSERT INTO enthaelt VALUES ('Ederle', 3, 001, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 002, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 003, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 004, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 005, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 006, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 007, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 008, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 009, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 010, 400);
INSERT INTO enthaelt VALUES ('Ederle', 3, 016, 700);
INSERT INTO enthaelt VALUES ('Ederle', 3, 017, 700);
INSERT INTO enthaelt VALUES ('Ederle', 3, 018, 700);

INSERT INTO enthaelt VALUES ('Ederle', 4, 001, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 002, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 003, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 004, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 005, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 006, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 007, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 008, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 009, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 010, 400);
INSERT INTO enthaelt VALUES ('Ederle', 4, 011, 300);
INSERT INTO enthaelt VALUES ('Ederle', 4, 012, 300);
INSERT INTO enthaelt VALUES ('Ederle', 4, 013, 300);


INSERT INTO enthaelt VALUES ('Megamarkt', 1, 001, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 002, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 003, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 004, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 005, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 006, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 007, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 008, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 009, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 010, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 011, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 012, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 013, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 014, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 015, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 016, 8000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 017, 8000);
INSERT INTO enthaelt VALUES ('Megamarkt', 1, 018, 8000);

INSERT INTO enthaelt VALUES ('Megamarkt', 2, 001, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 002, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 003, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 004, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 005, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 006, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 007, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 008, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 009, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 010, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 011, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 012, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 013, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 014, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 2, 015, 800);

INSERT INTO enthaelt VALUES ('Megamarkt', 3, 001, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 002, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 003, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 004, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 005, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 006, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 007, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 3, 008, 2000);

INSERT INTO enthaelt VALUES ('Megamarkt', 4, 023, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 4, 024, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 4, 025, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 4, 026, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 4, 027, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 4, 105, 5);

INSERT INTO enthaelt VALUES ('Megamarkt', 5, 001, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 003, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 005, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 007, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 009, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 023, 3000);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 024, 3000);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 025, 3000);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 026, 3000);
INSERT INTO enthaelt VALUES ('Megamarkt', 5, 027, 3000);

INSERT INTO enthaelt VALUES ('Megamarkt', 6, 001, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 002, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 003, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 004, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 005, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 006, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 007, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 008, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 009, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 010, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 019, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 020, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 021, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 6, 022, 3500);

INSERT INTO enthaelt VALUES ('Megamarkt', 7, 001, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 002, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 003, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 004, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 005, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 006, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 007, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 008, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 009, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 010, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 011, 1500);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 012, 1500);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 013, 1500);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 014, 1500);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 015, 1500);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 028, 1000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 029, 1000);
INSERT INTO enthaelt VALUES ('Megamarkt', 7, 030, 1000);

INSERT INTO enthaelt VALUES ('Megamarkt', 8, 001, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 8, 003, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 8, 005, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 8, 007, 3500);
INSERT INTO enthaelt VALUES ('Megamarkt', 8, 009, 3500);

INSERT INTO enthaelt VALUES ('Megamarkt', 9, 016, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 017, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 018, 1400);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 001, 1600);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 003, 1600);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 005, 1600);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 007, 1600);
INSERT INTO enthaelt VALUES ('Megamarkt', 9, 009, 1600);

INSERT INTO enthaelt VALUES ('Megamarkt', 10, 001, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 003, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 005, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 007, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 009, 1700);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 016, 3800);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 017, 3800);
INSERT INTO enthaelt VALUES ('Megamarkt', 10, 018, 3800);

INSERT INTO enthaelt VALUES ('Megamarkt', 11, 001, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 002, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 003, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 004, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 005, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 006, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 007, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 008, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 009, 5000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 010, 4000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 011, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 012, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 013, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 014, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 015, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 016, 8000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 017, 8000);
INSERT INTO enthaelt VALUES ('Megamarkt', 11, 018, 8000);

INSERT INTO enthaelt VALUES ('Megamarkt', 12, 001, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 002, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 003, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 004, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 005, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 006, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 007, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 008, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 009, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 010, 2000);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 011, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 012, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 013, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 014, 800);
INSERT INTO enthaelt VALUES ('Megamarkt', 12, 015, 800);


INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 001, 300);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 016, 500);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 017, 500);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 018, 600);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 003, 300);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 1, 005, 300);

INSERT INTO enthaelt VALUES ('Naschen, Ja!', 2, 011, 250);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 2, 012, 250);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 2, 013, 250);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 2, 014, 250);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 2, 015, 250);

INSERT INTO enthaelt VALUES ('Naschen, Ja!', 3, 001, 400);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 3, 002, 400);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 3, 003, 400);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 3, 007, 400);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 3, 005, 400);

INSERT INTO enthaelt VALUES ('Naschen, Ja!', 4, 004, 120);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 4, 006, 120);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 4, 008, 120);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 4, 009, 300);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 4, 010, 120);

INSERT INTO enthaelt VALUES ('Naschen, Ja!', 5, 023, 500);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 5, 024, 300);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 5, 025, 80);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 5, 026, 230);
INSERT INTO enthaelt VALUES ('Naschen, Ja!', 5, 027, 120);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 1, 112, 1);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 1, 002, 350);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 1, 004, 350);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 1, 006, 350);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 2, 019, 200);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 2, 020, 180);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 2, 021, 120);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 2, 022, 150);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 2, 001, 300);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 3, 113, 1);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 3, 019, 30);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 3, 020, 40);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 3, 021, 80);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 3, 022, 100);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 4, 022, 40);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 5, 114, 1);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 5, 019, 230);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 5, 020, 200);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 5, 021, 180);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 5, 022, 200);

INSERT INTO enthaelt VALUES ('Bitter und Scharf', 6, 019, 30);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 6, 020, 40);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 6, 021, 80);
INSERT INTO enthaelt VALUES ('Bitter und Scharf', 6, 022, 30);
