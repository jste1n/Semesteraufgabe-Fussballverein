-- Standardsortiment
INSERT INTO Standardsortiment VALUES (001, 0.99, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (002, 1.49, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (003, 0.99, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (004, 1.49, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (005, 0.99, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (006, 1.49, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (007, 0.99, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (008, 1.49, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (009, 0.99, 'Alufolie + Papier bedruckt');
INSERT INTO Standardsortiment VALUES (010, 1.49, 'Alufolie + Papier bedruckt');

INSERT INTO Standardsortiment VALUES (011, 2.49, 'Kartonschachtel');
INSERT INTO Standardsortiment VALUES (012, 2.49, 'Kartonschachtel');
INSERT INTO Standardsortiment VALUES (013, 2.49, 'Kartonschachtel');
INSERT INTO Standardsortiment VALUES (014, 2.49, 'Kartonschachtel');
INSERT INTO Standardsortiment VALUES (015, 2.49, 'Kartonschachtel');

INSERT INTO Standardsortiment VALUES (016, 1.29, 'Plastikfolie bedruckt');
INSERT INTO Standardsortiment VALUES (017, 1.59, 'Plastikfolie bedruckt');
INSERT INTO Standardsortiment VALUES (018, 0.99, 'Plastikfolie bedruckt');

INSERT INTO Standardsortiment VALUES (019, 1.29, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (020, 1.49, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (021, 1.99, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (022, 1.39, 'Alufolie bedruckt');

INSERT INTO Standardsortiment VALUES (023, 1.29, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (024, 1.49, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (025, 1.99, 'Alufolie bedruckt');
INSERT INTO Standardsortiment VALUES (026, 3.99, 'Kartonschachtel');
INSERT INTO Standardsortiment VALUES (027, 2.49, 'Plastiksackerl');

INSERT INTO Standardsortiment VALUES (028, 0.80, 'Plastikfolie bedruckt');
INSERT INTO Standardsortiment VALUES (029, 0.79, 'Plastikfolie bedruckt');
INSERT INTO Standardsortiment VALUES (030, 1.79, 'Plastiksackerl');
