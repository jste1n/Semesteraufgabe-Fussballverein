-- Kuendigung

INSERT INTO Kuendigung VALUES (11, DATE '2008-10-30');
INSERT INTO Kuendigung VALUES (24, DATE '2004-08-30');
INSERT INTO Kuendigung VALUES (01, DATE '2004-09-30');
INSERT INTO Kuendigung VALUES (05, DATE '2003-01-31');
INSERT INTO Kuendigung VALUES (08, DATE '2003-01-31');
INSERT INTO Kuendigung VALUES (17, DATE '2007-04-30');
INSERT INTO Kuendigung VALUES (26, DATE '2004-06-30');
INSERT INTO Kuendigung VALUES (27, DATE '2004-06-30');
INSERT INTO Kuendigung VALUES (28, DATE '2005-12-31');

-- 11, 24 (sind Kuenstler und Mitarbeiter), 01, 05, 08, 17, 26, 27, 28 bereits wieder gekuendigt 
