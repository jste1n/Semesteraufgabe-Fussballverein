-- Kuenstler
INSERT INTO Kuenstler VALUES (10, 10);
INSERT INTO Kuenstler VALUES (11, 3);
INSERT INTO Kuenstler VALUES (12, 3);
INSERT INTO Kuenstler VALUES (14, 0);
INSERT INTO Kuenstler VALUES (24, 1);
INSERT INTO Kuenstler VALUES (30, 10);
INSERT INTO Kuenstler VALUES (33, 8);
INSERT INTO Kuenstler VALUES (34, 7);
INSERT INTO Kuenstler VALUES (36, 7);
INSERT INTO Kuenstler VALUES (38, 4);
INSERT INTO Kuenstler VALUES (39, 9);
INSERT INTO Kuenstler VALUES (40, 1);

-- 10, 11, 24, 30 Kuenstler und Mitarbeiter
