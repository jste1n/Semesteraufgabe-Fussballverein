-- zeigt
INSERT INTO zeigt VALUES (10, 101, DATE '2006-03-05', 'Die Besten Schokolademacher', 2);
INSERT INTO zeigt VALUES (12, 107, DATE '2006-03-05', 'Die Besten Schokolademacher', 6);
INSERT INTO zeigt VALUES (34, 111, DATE '2006-03-05', 'Die Besten Schokolademacher', 4);
INSERT INTO zeigt VALUES (40, 116, DATE '2006-03-05', 'Die Besten Schokolademacher', 14);

INSERT INTO zeigt VALUES (10, 101, DATE '2007-03-04', 'Die Besten Schokolademacher', 1);
INSERT INTO zeigt VALUES (12, 108, DATE '2007-03-04', 'Die Besten Schokolademacher', 2);
INSERT INTO zeigt VALUES (39, 114, DATE '2007-03-04', 'Die Besten Schokolademacher', 7);
INSERT INTO zeigt VALUES (36, 113, DATE '2007-03-04', 'Die Besten Schokolademacher', 4);
INSERT INTO zeigt VALUES (40, 116, DATE '2007-03-04', 'Die Besten Schokolademacher', 10);

INSERT INTO zeigt VALUES (10, 103, DATE '2007-03-04', 'Die Besten Schokolademacher', 6);
INSERT INTO zeigt VALUES (12, 107, DATE '2007-03-04', 'Die Besten Schokolademacher', 1);
INSERT INTO zeigt VALUES (40, 116, DATE '2008-03-02', 'Die Besten Schokolademacher', 16);


INSERT INTO zeigt VALUES (14, 110, DATE '2007-08-24', 'Kunstschau 2007', 5);
INSERT INTO zeigt VALUES (39, 114, DATE '2007-08-24', 'Kunstschau 2007', 7);
INSERT INTO zeigt VALUES (36, 113, DATE '2007-08-24', 'Kunstschau 2007', 2);

INSERT INTO zeigt VALUES (14, 110, DATE '2008-08-26', 'Kunstschau 2008', 4);
INSERT INTO zeigt VALUES (39, 110, DATE '2008-08-26', 'Kunstschau 2008', 6);
INSERT INTO zeigt VALUES (36, 110, DATE '2008-08-26', 'Kunstschau 2008', 9);
INSERT INTO zeigt VALUES (12, 109, DATE '2008-08-26', 'Kunstschau 2008', 12);


INSERT INTO zeigt VALUES (10, 101, DATE '2006-05-21', 'Internactional Chocolate Contest', 12);
INSERT INTO zeigt VALUES (34, 111, DATE '2006-05-21', 'Internactional Chocolate Contest', 1);

INSERT INTO zeigt VALUES (12, 109, DATE '2007-05-20', 'Internactional Chocolate Contest', 1);
INSERT INTO zeigt VALUES (39, 114, DATE '2007-05-20', 'Internactional Chocolate Contest', 3);
INSERT INTO zeigt VALUES (34, 111, DATE '2007-05-20', 'Internactional Chocolate Contest', 16);
INSERT INTO zeigt VALUES (12, 107, DATE '2007-05-20', 'Internactional Chocolate Contest', 4);

INSERT INTO zeigt VALUES (14, 110, DATE '2008-05-18', 'Internactional Chocolate Contest', 1);


INSERT INTO zeigt VALUES (38, 115, DATE '2006-11-16', 'Europaeischer Suessigkeitenkongress', 2);
INSERT INTO zeigt VALUES (34, 111, DATE '2006-11-16', 'Europaeischer Suessigkeitenkongress', 8);
INSERT INTO zeigt VALUES (33, 106, DATE '2006-11-16', 'Europaeischer Suessigkeitenkongress', 19);
INSERT INTO zeigt VALUES (14, 110, DATE '2006-11-16', 'Europaeischer Suessigkeitenkongress', 6);

INSERT INTO zeigt VALUES (38, 115, DATE '2007-11-18', 'Europaeischer Suessigkeitenkongress', 2);
INSERT INTO zeigt VALUES (34, 111, DATE '2007-11-18', 'Europaeischer Suessigkeitenkongress', 8);
INSERT INTO zeigt VALUES (33, 106, DATE '2007-11-18', 'Europaeischer Suessigkeitenkongress', 10);

INSERT INTO zeigt VALUES (38, 112, DATE '2008-11-19', 'Europaeischer Suessigkeitenkongress', 1);
INSERT INTO zeigt VALUES (34, 111, DATE '2008-11-19', 'Europaeischer Suessigkeitenkongress', 8);
INSERT INTO zeigt VALUES (33, 106, DATE '2008-11-19', 'Europaeischer Suessigkeitenkongress', 19);


INSERT INTO zeigt VALUES (11, 104, DATE '2007-12-23', 'Die Schoensten Weihnachtsmotive', 2);
INSERT INTO zeigt VALUES (24, 105, DATE '2007-12-23', 'Die Schoensten Weihnachtsmotive', 1);
INSERT INTO zeigt VALUES (33, 106, DATE '2007-12-23', 'Die Schoensten Weihnachtsmotive', 4);
INSERT INTO zeigt VALUES (40, 116, DATE '2007-12-23', 'Die Schoensten Weihnachtsmotive', 9);

