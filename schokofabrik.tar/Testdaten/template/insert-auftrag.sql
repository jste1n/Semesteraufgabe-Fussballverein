-- Auftrag
INSERT INTO Auftrag VALUES ('Sweet and Sons', 1, DATE '2007-11-25', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Sweet and Sons', 2, DATE '2008-01-23', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Sweet and Sons', 3, DATE '2008-03-14', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Sweet and Sons', 4, DATE '2008-09-16', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Sweet and Sons', 5, DATE '2008-11-15', 'in Produktion');

INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 1, DATE '2007-03-20', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 2, DATE '2007-07-12', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 3, DATE '2007-12-24', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 4, DATE '2008-01-08', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 5, DATE '2008-05-19', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Schokoladenparadies Erdl', 6, DATE '2008-08-16', 'in Produktion');

INSERT INTO Auftrag VALUES ('Gesuender Leben', 1, DATE '2007-11-13', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Gesuender Leben', 2, DATE '2007-12-13', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Gesuender Leben', 3, DATE '2008-01-18', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Gesuender Leben', 4, DATE '2008-02-27', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Gesuender Leben', 5, DATE '2008-08-28', 'in Produktion');
INSERT INTO Auftrag VALUES ('Gesuender Leben', 6, DATE '2008-09-29', 'in Produktion');

INSERT INTO Auftrag VALUES ('Chocolatier Holler', 1, DATE '2008-07-13', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Chocolatier Holler', 2, DATE '2008-08-15', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Chocolatier Holler', 3, DATE '2008-09-19', 'in Produktion');

INSERT INTO Auftrag VALUES ('Ederle', 1, DATE '2007-09-26', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Ederle', 2, DATE '2008-11-10', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Ederle', 3, DATE '2008-05-17', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Ederle', 4, DATE '2008-09-19', 'in Produktion');

INSERT INTO Auftrag VALUES ('Megamarkt', 1, DATE '2007-10-20', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 2, DATE '2007-10-19', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 3, DATE '2007-11-17', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 4, DATE '2007-11-19', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 5, DATE '2007-12-10', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 6, DATE '2008-03-20', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 7, DATE '2008-04-27', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 8, DATE '2008-05-16', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 9, DATE '2008-07-15', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Megamarkt', 10, DATE '2008-08-29', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Megamarkt', 11, DATE '2008-10-01', 'in Produktion');
INSERT INTO Auftrag VALUES ('Megamarkt', 12, DATE '2008-10-08', 'in Vorbereitung');

INSERT INTO Auftrag VALUES ('Naschen, Ja!', 1, DATE '2007-12-18', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Naschen, Ja!', 2, DATE '2007-12-25', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Naschen, Ja!', 3, DATE '2008-10-20', 'in Produktion');
INSERT INTO Auftrag VALUES ('Naschen, Ja!', 4, DATE '2008-11-03', 'in Produktion');
INSERT INTO Auftrag VALUES ('Naschen, Ja!', 5, DATE '2008-11-16', 'in Vorbereitung');

INSERT INTO Auftrag VALUES ('Bitter und Scharf', 1, DATE '2007-01-25', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Bitter und Scharf', 2, DATE '2007-03-10', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Bitter und Scharf', 3, DATE '2007-03-16', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Bitter und Scharf', 4, DATE '2007-03-17', 'abgeschlossen');
INSERT INTO Auftrag VALUES ('Bitter und Scharf', 5, DATE '2008-03-01', 'bereit zur Auslieferung');
INSERT INTO Auftrag VALUES ('Bitter und Scharf', 6, DATE '2008-03-05', 'bereit zur Auslieferung');
