-- Kunstschau
INSERT INTO Kunstschau VALUES (DATE '2006-03-05', 'Die Besten Schokolademacher', 'Graz', 'Oesterreich');
INSERT INTO Kunstschau VALUES (DATE '2007-03-04', 'Die Besten Schokolademacher', 'Graz', 'Oesterreich');
INSERT INTO Kunstschau VALUES (DATE '2008-03-02', 'Die Besten Schokolademacher', 'Graz', 'Oesterreich');

INSERT INTO Kunstschau VALUES (DATE '2007-08-24', 'Kunstschau 2007', 'Salzburg', 'Oesterreich');
INSERT INTO Kunstschau VALUES (DATE '2008-08-26', 'Kunstschau 2008', 'Innsbruck', 'Oesterreich');

INSERT INTO Kunstschau VALUES (DATE '2006-05-21', 'Internactional Chocolate Contest', 'Hobart', 'Australien');
INSERT INTO Kunstschau VALUES (DATE '2007-05-20', 'Internactional Chocolate Contest', 'New York', 'USA');
INSERT INTO Kunstschau VALUES (DATE '2008-05-18', 'Internactional Chocolate Contest', 'Athen', 'Griechenland');

INSERT INTO Kunstschau VALUES (DATE '2006-11-16', 'Europaeischer Suessigkeitenkongress', 'Oslo', 'Norwegen');
INSERT INTO Kunstschau VALUES (DATE '2007-11-18', 'Europaeischer Suessigkeitenkongress', 'Wien', 'Oesterreich');
INSERT INTO Kunstschau VALUES (DATE '2008-11-19', 'Europaeischer Suessigkeitenkongress', 'Muenchen', 'Deutschland');

INSERT INTO Kunstschau VALUES (DATE '2007-12-23', 'Die Schoensten Weihnachtsmotive', 'Bern', 'Schweiz');


